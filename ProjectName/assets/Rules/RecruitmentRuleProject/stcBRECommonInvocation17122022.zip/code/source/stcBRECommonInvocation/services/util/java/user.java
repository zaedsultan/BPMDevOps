package stcBRECommonInvocation.services.util.java;

// -----( IS Java Code Template v1.2

import com.wm.data.*;
import com.wm.util.Values;
import com.wm.app.b2b.server.Service;
import com.wm.app.b2b.server.ServiceException;
// --- <<IS-START-IMPORTS>> ---
import com.wm.app.b2b.server.InvokeState;
import com.wm.app.b2b.server.User;
// --- <<IS-END-IMPORTS>> ---

public final class user

{
	// ---( internal utility methods )---

	final static user _instance = new user();

	static user _newInstance() { return new user(); }

	static user _cast(Object o) { return (user)o; }

	// ---( server methods )---




	public static final void impersonateUser (IData pipeline)
        throws ServiceException
	{
		// --- <<IS-START(impersonateUser)>> ---
		// @sigtype java 3.5
		// [i] field:0:required userId
		 //
		
		// pipeline
		IDataCursor pipelineCursor = pipeline.getCursor();
			String	userId = IDataUtil.getString( pipelineCursor, "userId" );
			InvokeState.getCurrentState().setUser(new User(userId));
		pipelineCursor.destroy();
		
		// pipeline
		// --- <<IS-END>> ---

                
	}
}

